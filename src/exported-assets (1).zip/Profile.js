import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import '../styles/Profile.css';

const Profile = () => {
  const { currentUser, logout } = useAuth();
  const [income, setIncome] = useState(0);

  return (
    <div className="profile">
      <div className="profile-header">
        <h1>Profile</h1>
      </div>

      <div className="profile-content">
        <div className="profile-card">
          <div className="user-info">
            <h2>User Information</h2>
            <div className="info-item">
              <label>Email:</label>
              <span>{currentUser?.email}</span>
            </div>
            {currentUser?.displayName && (
              <div className="info-item">
                <label>Name:</label>
                <span>{currentUser.displayName}</span>
              </div>
            )}
          </div>

          <div className="income-section">
            <h3>Monthly Income</h3>
            <div className="form-group">
              <input
                type="number"
                value={income}
                onChange={(e) => setIncome(e.target.value)}
                placeholder="Enter monthly income"
                className="income-input"
              />
              <button className="save-btn">Save Income</button>
            </div>
          </div>

          <div className="actions-section">
            <button onClick={logout} className="logout-btn">
              Logout
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;